import React from 'react';

const InfoSection = () => {
  return (
    <div className="mx-4 my-6 bg-white rounded-lg overflow-hidden shadow-md">
      <div className="border-b-4 border-[#1351B4] bg-[#1351B4] py-4 px-6">
        <h2 className="text-xl font-bold text-white uppercase text-center">Informações Importantes</h2>
      </div>
      
      <div className="px-6 py-4">
        <div className="mb-6 flex">
          <div className="w-1 bg-[#2557a7] mr-4"></div>
          <div>
            <h3 className="text-gray-600 font-semibold">OPORTUNIDADE:</h3>
            <p className="text-[rgb(19,81,180)] text-2xl font-bold">20 MIL VAGAS</p>
            <p className="text-gray-600">para garis disponíveis em todo o país</p>
          </div>
        </div>
        
        <div className="mb-6 flex">
          <div className="w-1 bg-[#2557a7] mr-4"></div>
          <div>
            <h3 className="text-gray-600 font-semibold">REMUNERAÇÃO:</h3>
            <p className="text-[rgb(19,81,180)] text-2xl font-bold">R$ 2.795,00 iniciais</p>
            <p className="text-gray-600">vale-alimentação, transporte, saúde, creche, e meia-entrada em eventos</p>
          </div>
        </div>
        
        <div className="mb-6 flex">
          <div className="w-1 bg-[#2557a7] mr-4"></div>
          <div>
            <h3 className="text-gray-600 font-semibold">ESCOLARIDADE:</h3>
            <p className="text-[rgb(19,81,180)] text-2xl font-bold">ENSINO FUNDAMENTAL</p>
            <p className="text-gray-600">(mínimo 5º ano completo)</p>
          </div>
        </div>
        
        <div className="flex">
          <div className="w-1 bg-[#2557a7] mr-4"></div>
          <div>
            <h3 className="text-gray-600 font-semibold">INSCRIÇÕES:</h3>
            <p className="text-[rgb(19,81,180)] text-2xl font-bold">03 a 23 de junho de 2025</p>
            <p className="text-gray-600">Vagas limitadas por cidade!</p>
          </div>
        </div>
        
        <div className="mt-8 bg-blue-50 p-3 border border-blue-100 rounded text-center">
          <span className="font-bold text-[#1351B4]">Última atualização: Junho/2025</span>
        </div>
      </div>
    </div>
  );
};

export default InfoSection;