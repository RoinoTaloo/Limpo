import React from 'react';

const ProgramTitle = () => {
  return (
    <div className="flex flex-col items-center text-center p-4 bg-white">
      <div className="relative w-full max-w-md">
        <div className="rounded-3xl overflow-hidden flex justify-center items-center">
          <div className="text-center">
            <div className="flex justify-center items-center">
              <img 
                src="/image.png" 
                alt="Brasil Mais Limpo Logo" 
                className="w-[300px] h-[300px] object-contain"
              />
            </div>
          </div>
        </div>
      </div>
      
      <div className="w-full max-w-2xl mt-6">
        <h2 className="text-[#2557a7] text-xl font-bold text-left mb-4">Sobre o Programa</h2>
        <p className="text-left text-gray-800">
          O programa Brasil Mais Limpo é uma iniciativa do Governo Federal que marca o Programa Nacional de Emprego e Cidadania Urbana. Emprego com dignidade. Cuidado com a cidade. Futuro para todos.
        </p>
        <p className="text-left text-gray-800 mt-4">
          O Governo Federal, em parceria com prefeituras e empresas de limpeza urbana, lançou o Brasil Mais Limpo, um programa emergencial que vai contratar 20 mil garis em todos os estados brasileiros.
        </p>
        <div className="text-left mt-4">
          <p className="text-gray-800 mb-1">Não precisa fazer prova!</p>
          <p className="text-gray-800">Seleção por análise curricular + critérios sociais</p>
        </div>
      </div>

      <div className="w-full mt-8">
        <img 
          src="/Front_1 copy.png" 
          alt="Gari trabalhando" 
          className="w-full h-auto rounded-lg shadow-lg"
        />
      </div>
    </div>
  );
};

export default ProgramTitle;