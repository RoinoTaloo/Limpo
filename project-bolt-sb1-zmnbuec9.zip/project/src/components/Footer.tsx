import React from 'react';
import { ChevronDown } from 'lucide-react';

const Footer = () => {
  return (
    <div className="bg-[#0a1f44] text-white py-6">
      <div className="container mx-auto px-4">
        <div className="py-3">
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Gov.br_logo.svg/1200px-Gov.br_logo.svg.png" 
            alt="Government of Brazil logo showing gov.br in white text" 
            className="w-24"
          />
        </div>
        <div className="border-t border-gray-600"></div>
        <nav>
          <ul className="text-sm">
            <li className="py-3">
              <a href="#" className="text-sm hover:underline">BRASIL MAIS LIMPO</a>
            </li>
            <li className="border-t border-gray-600 py-3 flex justify-between items-center">
              <a href="#" className="text-sm hover:underline">ASSUNTOS</a>
              <ChevronDown size={16} />
            </li>
            <li className="border-t border-gray-600 py-3 flex justify-between items-center">
              <a href="#" className="text-sm hover:underline">PROGRAMA</a>
              <ChevronDown size={16} />
            </li>
            <li className="border-t border-gray-600 py-3 flex justify-between items-center">
              <a href="#" className="text-sm hover:underline">COMPOSIÇÃO</a>
              <ChevronDown size={16} />
            </li>
            <li className="border-t border-gray-600 py-3 flex justify-between items-center">
              <a href="#" className="text-sm hover:underline">ACESSO À INFORMAÇÃO</a>
              <ChevronDown size={16} />
            </li>
            <li className="border-t border-gray-600 py-3 flex justify-between items-center">
              <a href="#" className="text-sm hover:underline">CENTRAIS DE CONTEÚDO</a>
              <ChevronDown size={16} />
            </li>
            <li className="border-t border-gray-600 py-3 flex justify-between items-center">
              <a href="#" className="text-sm hover:underline">CANAIS DE ATENDIMENTO</a>
              <ChevronDown size={16} />
            </li>
            <li className="border-t border-gray-600 py-3 flex justify-between items-center">
              <a href="#" className="text-sm hover:underline">CAMPANHAS NACIONAIS</a>
              <ChevronDown size={16} />
            </li>
            <li className="border-t border-gray-600"></li>
          </ul>
        </nav>
        <div className="mt-4 flex items-center">
          <span className="text-sm hover:underline cursor-pointer">Redefinir Cookies</span>
        </div>
        <div className="mt-6">
          <div className="mb-3">
            <div className="text-sm font-bold mb-3">Redes sociais</div>
            <ul className="flex space-x-2">
              <li>
                <a href="https://www.youtube.com/minsaudebr" aria-label="YouTube" className="flex items-center justify-center w-8 h-8 bg-opacity-20 bg-white rounded-full">
                  <i className="fab fa-youtube text-sm"></i>
                </a>
              </li>
              <li>
                <a href="https://www.facebook.com/minsaude" aria-label="Facebook" className="flex items-center justify-center w-8 h-8 bg-opacity-20 bg-white rounded-full">
                  <i className="fab fa-facebook-f text-sm"></i>
                </a>
              </li>
              <li>
                <a href="https://www.instagram.com/minsaude" aria-label="Instagram" className="flex items-center justify-center w-8 h-8 bg-opacity-20 bg-white rounded-full">
                  <i className="fab fa-instagram text-sm"></i>
                </a>
              </li>
              <li>
                <a href="https://soundcloud.com/min_saude" aria-label="SoundCloud" className="flex items-center justify-center w-8 h-8 bg-opacity-20 bg-white rounded-full">
                  <i className="fab fa-soundcloud text-sm"></i>
                </a>
              </li>
              <li>
                <a href="https://www.flickr.com/ministeriodasaude" aria-label="Flickr" className="flex items-center justify-center w-8 h-8 bg-opacity-20 bg-white rounded-full">
                  <i className="fab fa-flickr text-sm"></i>
                </a>
              </li>
              <li>
                <a href="https://linkedin.com/company/ministeriodasaude" aria-label="LinkedIn" className="flex items-center justify-center w-8 h-8 bg-opacity-20 bg-white rounded-full">
                  <i className="fab fa-linkedin-in text-sm"></i>
                </a>
              </li>
              <li>
                <a href="https://www.tiktok.com/@minsaudebr" aria-label="TikTok" className="flex items-center justify-center w-8 h-8 bg-opacity-20 bg-white rounded-full">
                  <i className="fab fa-tiktok text-sm"></i>
                </a>
              </li>
            </ul>
          </div>
          <div className="mt-4">
            <a href="https://www.gov.br/acessoainformacao/pt-br" title="Acesse o portal sobre o acesso à informação">
              <div className="flex items-center">
                <div className="bg-[#2563eb] rounded-full w-10 h-10 flex items-center justify-center mr-2">
                  <span className="text-white text-base">i</span>
                </div>
                <div className="text-white text-xs font-bold leading-tight">
                  ACESSO À<br/>INFORMAÇÃO
                </div>
              </div>
            </a>
          </div>
          <div className="texto-copyright mt-6 text-sm text-gray-300">
            Todo o conteúdo deste site está publicado sob a licença <a rel="license" href="https://creativecommons.org/licenses/by-nd/3.0/deed.pt_BR" className="text-blue-400 hover:text-blue-300">Creative Commons Atribuição-SemDerivações 3.0 Não Adaptada</a>.
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;