import React from 'react';

const BenefitsSection = () => {
  return (
    <div className="mx-4 my-6 bg-white rounded-lg overflow-hidden shadow-md">
      <div className="bg-[#2557a7] text-white text-center py-4 px-6">
        <h2 className="text-xl font-bold">BENEFÍCIOS E REMUNERAÇÃO</h2>
      </div>
      
      <div className="p-6">
        <div className="mb-6 flex">
          <div className="w-1 bg-[#2557a7] mr-4"></div>
          <div>
            <h3 className="text-gray-600 font-semibold">SALÁRIO BASE:</h3>
            <p className="text-[rgb(19,81,180)] text-2xl font-bold">R$ 2.795,00 iniciais</p>
            <p className="text-gray-600">(ajustável conforme o estado)</p>
          </div>
        </div>
        
        <div className="mb-6 flex">
          <div className="w-1 bg-[#2557a7] mr-4"></div>
          <div>
            <h3 className="text-gray-600 font-semibold">BENEFÍCIOS DIRETOS:</h3>
            <p className="text-gray-600">• Vale-alimentação e vale-transporte</p>
            <p className="text-gray-600">• Auxílio-creche</p>
            <p className="text-gray-600">• Café da manhã nas bases operacionais</p>
          </div>
        </div>
        
        <div className="mb-6 flex">
          <div className="w-1 bg-[#2557a7] mr-4"></div>
          <div>
            <h3 className="text-gray-600 font-semibold">SEGURANÇA E SAÚDE:</h3>
            <p className="text-gray-600">• Seguro de vida</p>
            <p className="text-gray-600">• Plano básico de saúde e odontológico</p>
          </div>
        </div>
        
        <div className="flex">
          <div className="w-1 bg-[#2557a7] mr-4"></div>
          <div>
            <h3 className="text-gray-600 font-semibold">BENEFÍCIOS ADICIONAIS:</h3>
            <p className="text-gray-600">• Direito à meia-entrada em eventos culturais</p>
            <p className="text-gray-600">• Acesso à formação técnica em limpeza pública</p>
          </div>
        </div>
        
        <div className="mt-8 bg-blue-50 p-3 border border-blue-100 rounded text-center">
          <span className="font-bold text-[#1351B4]">Todos os garis contratados terão carteira assinada</span>
        </div>
      </div>
    </div>
  );
};

export default BenefitsSection;