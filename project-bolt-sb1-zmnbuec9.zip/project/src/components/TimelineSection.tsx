import React from 'react';

const TimelineSection = () => {
  return (
    <div className="mx-4 my-6 bg-white rounded-lg overflow-hidden">
      <div className="bg-[#2557a7] text-white text-center py-4 px-6">
        <h2 className="text-xl font-bold">CRONOGRAMA DO PROCESSO</h2>
      </div>
      
      <div className="px-6 py-4">
        <div className="mt-4">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-300">
                <th className="text-left py-2 text-gray-700">Etapa</th>
                <th className="text-left py-2 text-gray-700">Data</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-200">
                <td className="py-2 text-gray-700">Inscrições</td>
                <td className="py-2 text-gray-700">03 a 23 de junho de 2025</td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="py-2 text-gray-700">Resultado da análise</td>
                <td className="py-2 text-gray-700">25 de junho de 2025</td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="py-2 text-gray-700">Recursos</td>
                <td className="py-2 text-gray-700">26 a 28 de junho de 2025</td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="py-2 text-gray-700">Resultado final</td>
                <td className="py-2 text-gray-700">30 de junho de 2025</td>
              </tr>
              <tr>
                <td className="py-2 text-gray-700">Início das contratações</td>
                <td className="py-2 text-gray-700">A partir de 02 de julho</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="mt-8 bg-blue-50 p-3 border border-blue-100 rounded text-center">
          <span className="font-bold text-[#1351B4]">Última atualização: junho/2025</span>
        </div>
      </div>
    </div>
  );
};

export default TimelineSection;