import React from 'react';

const PartnersSection = () => {
  return (
    <div className="mx-4 my-6 bg-white rounded-lg overflow-hidden">
      <div className="px-6 py-4">
        <h2 className="text-xl font-bold text-[#2557a7]">PARCERIAS LOCAIS (EMPRESAS REGIONAIS DE LIMPEZA URBANA)</h2>
        <p className="mt-2 text-gray-700">O programa é executado com apoio das empresas públicas e privadas que atuam em limpeza urbana nos municípios, como:</p>
        
        <div className="mt-4">
          <h3 className="font-semibold text-[#2557a7]">Principais Parceiras por Região</h3>
          
          <div className="mt-3">
            <p className="font-medium">Sudeste:</p>
            <p className="text-gray-700">COMLURB (<span className="text-[#2557a7]">RJ</span>), URBS (<span className="text-[#2557a7]">PR</span>), Localix (<span className="text-[#2557a7]">MG</span>), Construrban (<span className="text-[#2557a7]">SP</span>)</p>
          </div>
          
          <div className="mt-2">
            <p className="font-medium">Nordeste:</p>
            <p className="text-gray-700">Limpurb (<span className="text-[#2557a7]">BA</span>), Urbana (<span className="text-[#2557a7]">RN</span>), Emprel (<span className="text-[#2557a7]">PE</span>), Emsurb (<span className="text-[#2557a7]">SE</span>)</p>
          </div>
          
          <div className="mt-2">
            <p className="font-medium">Sul:</p>
            <p className="text-gray-700">CODECA (<span className="text-[#2557a7]">RS</span>), COMCAP (<span className="text-[#2557a7]">SC</span>), Ambiental SC</p>
          </div>
          
          <div className="mt-2">
            <p className="font-medium">Centro-Oeste:</p>
            <p className="text-gray-700">SLU (<span className="text-[#2557a7]">DF</span>), Comurg (<span className="text-[#2557a7]">GO</span>), Solurb (<span className="text-[#2557a7]">MS</span>)</p>
          </div>
          
          <div className="mt-2">
            <p className="font-medium">Norte:</p>
            <p className="text-gray-700">Emdur (<span className="text-[#2557a7]">RO</span>), Urbana Manaus (<span className="text-[#2557a7]">AM</span>), Emurb (<span className="text-[#2557a7]">AP</span>)</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PartnersSection;