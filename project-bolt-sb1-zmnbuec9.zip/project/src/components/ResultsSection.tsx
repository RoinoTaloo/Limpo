import React from 'react';

const ResultsSection = () => {
  return (
    <div className="mx-4 my-6">
      <div className="bg-[#2557a7] text-white text-center py-4 px-6 rounded-t-lg">
        <h2 className="text-xl font-bold">Resultados</h2>
      </div>
      
      <div className="bg-white p-6 rounded-b-lg shadow-md">
        <ul className="space-y-4">
          <li className="flex items-start">
            <span className="text-[#2557a7] font-bold mr-2">•</span>
            <span className="text-[rgb(19,81,180)]">187.580</span>
            <span className="text-gray-800 ml-2">inscrições já homologadas</span>
          </li>
          
          <li className="flex items-start">
            <span className="text-[#2557a7] font-bold mr-2">•</span>
            <div className="text-gray-800">
              <span className="text-[rgb(19,81,180)]">4.900</span>
              <span className="ml-2">municípios participantes</span>
            </div>
          </li>
          
          <li className="flex items-start">
            <span className="text-[#2557a7] font-bold mr-2">•</span>
            <div className="text-gray-800">
              <span className="text-[rgb(19,81,180)]">3.200</span>
              <span className="ml-2">tutores e</span>
              <span className="text-[rgb(19,81,180)] ml-2">7.500</span>
              <span className="ml-2">orientadores capacitando os selecionados</span>
            </div>
          </li>
          
          <li className="flex items-start">
            <span className="text-[#2557a7] font-bold mr-2">•</span>
            <div className="text-gray-800">
              <span className="text-[rgb(19,81,180)]">88%</span>
              <span className="ml-2">dos estudantes diplomadas(os) até julho de 2025</span>
            </div>
          </li>
        </ul>

        <div className="mt-8 bg-blue-50 p-3 border border-blue-100 rounded text-center">
          <span className="font-bold text-[#1351B4]">Última atualização: junho/2025</span>
        </div>
      </div>
    </div>
  );
};

export default ResultsSection;