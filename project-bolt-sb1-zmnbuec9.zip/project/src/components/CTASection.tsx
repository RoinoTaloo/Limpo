import React from 'react';
import { useNavigate } from 'react-router-dom';

const CTASection = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    // First scroll to top
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });

    // After scrolling, navigate to registration page
    setTimeout(() => {
      navigate('/inscricao');
    }, 500);
  };

  return (
    <div className="mx-4 my-6 bg-white rounded-lg overflow-hidden shadow-md">
      <div className="px-6 py-6">
        <h2 className="text-xl font-bold text-[#2557a7] text-center">GARANTA SUA VAGA AGORA!</h2>
        <p className="mt-3 text-center text-gray-700">Clique no botão abaixo para acessar o formulário de inscrição oficial:</p>
        
        <div className="flex justify-center mt-5">
          <button 
            onClick={handleClick}
            className="bg-[#2557a7] text-white font-bold py-3 px-6 rounded-lg transition-transform hover:scale-105"
          >
            QUERO ME INSCREVER AGORA
          </button>
        </div>
        
        <div className="mt-6 text-center">
          <p className="text-gray-700">Prazo final: 23 de junho de 2025</p>
          <p className="text-gray-700 mt-1">100% gratuito, seguro e com prioridade para quem mais precisa.</p>
        </div>
        
        <div className="mt-8 pt-4 border-t border-gray-200 text-center">
          <p className="text-[#2557a7] font-medium">Brasil Mais Limpo — Cuidando das cidades. Valorizando as pessoas.</p>
        </div>
      </div>
    </div>
  );
};

export default CTASection;