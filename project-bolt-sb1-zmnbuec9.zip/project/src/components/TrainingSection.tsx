import React from 'react';

const TrainingSection = () => {
  return (
    <div className="mx-4 my-6 bg-white rounded-lg overflow-hidden">
      <div className="px-6 py-4">
        <h2 className="text-xl font-bold text-[#2557a7]">FORMAÇÃO PROFISSIONAL GRATUITA</h2>
        <p className="mt-2 text-gray-700">Todos os aprovados receberão capacitação técnica gratuita em:</p>
        
        <ul className="mt-3 text-gray-700">
          <li className="mb-1">Saúde e segurança no trabalho</li>
          <li className="mb-1">Coleta seletiva e reciclagem</li>
          <li className="mb-1">Ética e cidadania urbana</li>
          <li className="mb-1">Atendimento à população</li>
        </ul>
        
        <p className="mt-3 text-gray-700">Parceria com SENAI, SENAC e Instituições Federais</p>
      </div>
    </div>
  );
};

export default TrainingSection;