import React from 'react';

const ContactSection = () => {
  return (
    <div className="mx-4 my-6 bg-white rounded-lg overflow-hidden shadow-md">
      <div className="border-b-4 border-[#1351B4] bg-[#1351B4] py-4 px-6">
        <h2 className="text-xl font-bold text-white uppercase text-center">Atendimento</h2>
      </div>
      
      <div className="px-6 py-4">
        <h3 className="text-[#1351B4] text-lg font-semibold">Ouvidoria Nacional do Brasil Mais Limpo</h3>
        <p className="mt-2 text-gray-700">Atendimento: de segunda-feira a sexta-feira, das 8h às 20h, e aos sábados, das 8h às 14h.</p>
      </div>
    </div>
  );
};

export default ContactSection;