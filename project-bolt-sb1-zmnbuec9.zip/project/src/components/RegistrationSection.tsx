import React from 'react';
import { useNavigate } from 'react-router-dom';

const RegistrationSection = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    // First scroll to top
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });

    // After scrolling, navigate to registration page
    setTimeout(() => {
      navigate('/inscricao');
    }, 500);
  };

  return (
    <div className="mx-4 my-6">
      <div className="bg-[#2557a7] text-white text-center py-4 px-6 rounded-t-lg">
        <h2 className="text-xl font-bold">Acessar Área de Inscrições</h2>
      </div>
      
      <div className="bg-white p-6 rounded-b-lg flex flex-col items-center shadow-md">
        <p className="text-red-600 font-medium mb-6 text-center">INSCREVA-SE AGORA! VAGAS LIMITADAS</p>
        
        <button 
          onClick={handleClick}
          className="bg-[#1451B4] text-white font-medium py-3 px-12 rounded-full hover:bg-[#0C3D99] transition-colors md:px-16 sm:px-8 sm:w-full sm:max-w-xs md:w-auto pulse-button"
        >
          Inscrições
        </button>
        
        <p className="text-gray-600 mt-6">Prazo: 03 a 23/06/2025</p>
      </div>
    </div>
  );
};

export default RegistrationSection;