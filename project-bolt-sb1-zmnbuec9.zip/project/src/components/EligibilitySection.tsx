import React from 'react';

const EligibilitySection = () => {
  return (
    <div className="mx-4 my-6 bg-white rounded-lg overflow-hidden">
      <div className="px-6 py-4">
        <h2 className="text-xl font-bold text-[#2557a7]">QUEM PODE PARTICIPAR?</h2>
        
        <div className="mt-4">
          <h3 className="font-semibold text-[#2557a7]">Requisitos Mínimos</h3>
          <ul className="list-disc pl-5 mt-2 text-gray-700">
            <li>Ensino fundamental (até o 5º ano)</li>
            <li>18 anos ou mais</li>
            <li>Morar no município onde deseja trabalhar</li>
          </ul>
        </div>
        
        <div className="mt-4">
          <h3 className="font-semibold text-[#2557a7]">Terão prioridade:</h3>
          <ul className="list-disc pl-5 mt-2 text-gray-700">
            <li>Desempregados há mais de 6 meses</li>
            <li>Chefes de família sem renda</li>
            <li>Moradores de comunidades ou regiões de risco</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default EligibilitySection;