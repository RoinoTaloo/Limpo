import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Modal from 'react-modal';
import Header from '../components/Header';
import Footer from '../components/Footer';

Modal.setAppElement('#root');

interface StepProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  status: 'completed' | 'loading' | 'pending';
}

const ConfirmationStep: React.FC<StepProps> = ({ icon, title, description, status }) => {
  return (
    <div className="flex items-start relative border-l-2 pl-4 py-1\" style={{ borderColor: status === 'completed' ? 'rgb(34, 197, 94)' : status === 'loading' ? '#2563eb' : '#d1d5db' }}>
      <div className="absolute -left-[11px] top-0">
        <div className={`${
          status === 'completed' ? 'bg-green-500' : 
          status === 'loading' ? 'bg-blue-500' : 
          'bg-gray-300'
        } text-white rounded-full w-5 h-5 flex items-center justify-center transition-all duration-300`}>
          {status === 'completed' && <i className="fas fa-check text-[10px]"></i>}
          {status === 'loading' && (
            <div className="w-3 h-3 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
          )}
        </div>
      </div>
      <div className="flex-grow">
        <div className="flex items-center">
          <div className={`mr-2 ${
            status === 'completed' ? 'text-green-600' :
            status === 'loading' ? 'text-blue-600' :
            'text-gray-400'
          }`}>
            {title === "Confirmação da Região" && <i className="fas fa-map-marker-alt"></i>}
            {title === "Salário Disponível" && <i className="fas fa-money-bill-wave"></i>}
            {title === "Benefícios Adicionais" && <i className="fas fa-gift"></i>}
            {title === "Treinamento Gratuito" && <i className="fas fa-graduation-cap"></i>}
          </div>
          <h4 className="font-medium">{title}</h4>
        </div>
        <div className="mt-1 ml-6">
          <p className={`${
            status === 'completed' ? 'text-gray-700' :
            status === 'loading' ? 'text-blue-600' :
            'text-gray-400'
          }`}>
            {status === 'loading' ? 'Verificando...' : description}
          </p>
        </div>
      </div>
    </div>
  );
};

const Confirmation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [progress, setProgress] = useState(0);
  const [selectedUnit, setSelectedUnit] = useState<any>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showFinalInfo, setShowFinalInfo] = useState(false);
  const [acceptNoShow, setAcceptNoShow] = useState(false);
  const [acceptTruthfulness, setAcceptTruthfulness] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const state = location.state as { selectedUnit?: any };
    if (state?.selectedUnit) {
      setSelectedUnit(state.selectedUnit);
    }
  }, [location]);

  const [steps, setSteps] = useState<StepProps[]>([
    {
      icon: <i className="fas fa-map-marker-alt"></i>,
      title: "Confirmação da Região",
      description: selectedUnit ? `${selectedUnit.name} - ${selectedUnit.vagas} vagas disponíveis` : "Verificando região...",
      status: 'loading'
    },
    {
      icon: <i className="fas fa-money-bill-wave"></i>,
      title: "Salário Disponível",
      description: "R$ 2.795,00 mensais",
      status: 'pending'
    },
    {
      icon: <i className="fas fa-gift"></i>,
      title: "Benefícios Adicionais",
      description: "Vale alimentação, transporte, plano de saúde e auxílio creche",
      status: 'pending'
    },
    {
      icon: <i className="fas fa-graduation-cap"></i>,
      title: "Treinamento Gratuito",
      description: selectedUnit ? `${selectedUnit.vagas} vagas com capacitação integral e efetiva` : "Consultando programas de capacitação...",
      status: 'pending'
    }
  ]);

  useEffect(() => {
    const validateSteps = async () => {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setSteps(prev => prev.map((step, idx) => 
        idx === 0 ? { ...step, status: 'completed' } :
        idx === 1 ? { ...step, status: 'loading' } : step
      ));

      await new Promise(resolve => setTimeout(resolve, 2000));
      setSteps(prev => prev.map((step, idx) => 
        idx === 1 ? { ...step, status: 'completed' } :
        idx === 2 ? { ...step, status: 'loading' } : step
      ));

      await new Promise(resolve => setTimeout(resolve, 2000));
      setSteps(prev => prev.map((step, idx) => 
        idx === 2 ? { ...step, status: 'completed' } :
        idx === 3 ? { ...step, status: 'loading' } : step
      ));

      await new Promise(resolve => setTimeout(resolve, 2000));
      setSteps(prev => prev.map((step, idx) => 
        idx === 3 ? { 
          ...step, 
          status: 'completed',
          description: selectedUnit ? 
            `${selectedUnit.vagas} vagas com capacitação integral e efetiva, com certificado reconhecido pelo SENAI e SENAC` :
            "Capacitação integral e efetiva, com certificado reconhecido pelo SENAI e SENAC"
        } : step
      ));

      setShowSuccess(true);
    };

    validateSteps();
  }, [selectedUnit]);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    return () => clearInterval(interval);
  }, []);

  const handleContinue = () => {
    setShowFinalInfo(true);
  };

  const handleFinishRegistration = () => {
    // First scroll to top
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });

    // After scrolling, show modal
    setTimeout(() => {
      setIsModalOpen(true);
    }, 500);

    // After showing modal for 3 seconds, navigate to registration page
    setTimeout(() => {
      setIsModalOpen(false);
      navigate('/inscricao');
    }, 3500);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const modalStyles = {
    content: {
      top: '50%',
      left: '50%',
      right: 'auto',
      bottom: 'auto',
      marginRight: '-50%',
      transform: 'translate(-50%, -50%)',
      padding: 0,
      border: 'none',
      borderRadius: '8px',
      backgroundColor: 'transparent',
      maxWidth: '400px',
      width: '90%',
    },
    overlay: {
      backgroundColor: 'rgba(0, 0, 0, 0.75)',
      zIndex: 1000,
    },
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      <div className="max-w-3xl mx-auto py-10">
        <div className="bg-white rounded-lg shadow-md p-6 mx-4">
          <div className="mb-8">
            <h1 className="text-[#1351B4] text-2xl font-bold mb-2">Inscrição no Programa Brasil Mais Limpo</h1>
            <h2 className="text-gray-600 text-lg mb-4">Confirmação da sua Inscrição</h2>
          </div>

          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-[#2563eb] transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            ></div>
          </div>

          <div className="space-y-8">
            {steps.map((step, index) => (
              <ConfirmationStep key={index} {...step} />
            ))}
          </div>

          {showSuccess && (
            <div className="mt-8 bg-green-50 border border-green-200 rounded-lg p-4">
              <p className="text-green-800 font-medium">Parabéns! Sua avaliação preliminar foi bem-sucedida.</p>
              <p className="text-green-600 text-sm mt-1">
                Clique no botão abaixo para finalizar sua inscrição no programa.
              </p>
            </div>
          )}

          {showSuccess && (
            <button
              onClick={handleContinue}
              className="mt-6 w-full bg-[#2563eb] text-white font-medium py-3 px-6 rounded-full hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              Continuar
            </button>
          )}

          {showFinalInfo && selectedUnit && (
            <div className="mt-8 space-y-6">
              <div className="bg-blue-50 rounded-lg p-6">
                <h3 className="text-center text-xl font-bold text-gray-900 mb-4">
                  Remuneração do Programa
                </h3>
                <div className="text-center">
                  <p className="text-3xl font-bold text-green-600">R$ 2.795,00</p>
                  <p className="text-gray-600">Salário mensal do profissional contratado</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-lg border">
                  <h4 className="font-semibold text-gray-900">Curso de capacitação profissional</h4>
                  <p className="text-gray-600 text-sm">Programa completo com duração de 1 mês</p>
                </div>

                <div className="bg-white p-4 rounded-lg border">
                  <h4 className="font-semibold text-gray-900">Material didático gratuito</h4>
                  <p className="text-gray-600 text-sm">Acesso a todos os recursos de aprendizagem</p>
                </div>

                <div className="bg-white p-4 rounded-lg border">
                  <h4 className="font-semibold text-gray-900">Certificado oficial</h4>
                  <p className="text-gray-600 text-sm">Reconhecido pelo SENAI e SENAC</p>
                </div>

                <div className="bg-white p-4 rounded-lg border">
                  <h4 className="font-semibold text-gray-900">Cobertura Nacional</h4>
                  <p className="text-gray-600 text-sm">Presente em mais de 4.900 municípios</p>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg border">
                <h3 className="font-semibold text-gray-900 mb-4">Unidade Selecionada:</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-semibold">{selectedUnit.name}</p>
                      <p className="text-sm text-gray-600">{selectedUnit.address}</p>
                    </div>
                    <span className="text-sm text-gray-500">{selectedUnit.distance} km</span>
                  </div>
                  <p className="text-[#1351B4] font-semibold mt-2">
                    Vagas disponíveis: {selectedUnit.vagas}
                  </p>
                </div>
              </div>

              <div className="border-t pt-6 w-full">
                <h3 className="text-lg font-semibold text-[#0C336F] mb-3">Termos de Compromisso</h3>
                <div className="space-y-6 mb-6">
                  <div className={`flex items-start p-4 rounded-md border ${
                    acceptNoShow ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                  } transition-colors duration-300`}>
                    <div className="flex-1">
                      <div className="flex items-start">
                        <div className="flex items-start h-5 mt-1">
                          <input
                            type="checkbox"
                            checked={acceptNoShow}
                            onChange={(e) => setAcceptNoShow(e.target.checked)}
                            className={`h-4 w-4 rounded-sm ${
                              acceptNoShow ? 'border-green-300' : 'border-red-300'
                            }`}
                          />
                        </div>
                        <label className={`ml-3 font-medium ${
                          acceptNoShow ? 'text-green-700' : 'text-red-700'
                        }`}>
                          Concordo com a política de não comparecimento
                        </label>
                      </div>
                      <p className={`mt-1 text-sm ml-8 ${
                        acceptNoShow ? 'text-green-600' : 'text-red-600'
                      }`}>
                        Caso não compareça à prova, estarei sujeito a <strong>multa de R$ 35,00</strong> e bloqueio temporário de 90 dias para novas inscrições em programas do governo.
                      </p>
                    </div>
                  </div>

                  <div className={`flex items-start p-4 rounded-md border ${
                    acceptTruthfulness ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                  } transition-colors duration-300`}>
                    <div className="flex-1">
                      <div className="flex items-start">
                        <div className="flex items-start h-5 mt-1">
                          <input
                            type="checkbox"
                            checked={acceptTruthfulness}
                            onChange={(e) => setAcceptTruthfulness(e.target.checked)}
                            className={`h-4 w-4 rounded-sm ${
                              acceptTruthfulness ? 'border-green-300' : 'border-red-300'
                            }`}
                          />
                        </div>
                        <label className={`ml-3 font-medium ${
                          acceptTruthfulness ? 'text-green-700' : 'text-red-700'
                        }`}>
                          Declaro que as informações são verdadeiras
                        </label>
                      </div>
                      <p className={`mt-1 text-sm ml-8 ${
                        acceptTruthfulness ? 'text-green-600' : 'text-red-600'
                      }`}>
                        A falsificação de informações ou documentos resultará em <strong>cancelamento imediato da inscrição</strong> e banimento permanente de todos os processos seletivos do programa.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center mt-6">
                  <button
                    onClick={handleFinishRegistration}
                    className="inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white py-2 bg-[#1451B4] hover:bg-blue-800 rounded-full h-14 px-8 text-lg w-full max-w-md"
                    disabled={!acceptNoShow || !acceptTruthfulness}
                  >
                    <i className="fas fa-check mr-2"></i>
                    Finalizar Inscrição
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onRequestClose={closeModal}
        style={modalStyles}
        contentLabel="Carregando Ambiente Seguro"
      >
        <div className="bg-white p-8 rounded-lg text-center">
          <img 
            src="https://www.gov.br/++theme++padrao_govbr/img/govbr-colorido-b.png"
            alt="gov.br"
            className="mx-auto mb-6 w-24"
          />
          
          <h2 className="text-[#1351B4] text-xl font-bold mb-4">
            Carregando Ambiente Seguro...
          </h2>
          
          <p className="text-gray-600 mb-6">
            Estamos preparando um ambiente seguro para o processamento do seu pagamento. Por favor, aguarde um momento.
          </p>
          
          <div className="flex justify-center mb-6">
            <div className="w-12 h-12 border-4 border-t-transparent border-[#1351B4] rounded-full animate-spin"></div>
          </div>
          
          <p className="text-sm text-gray-500">
            Seus dados estão protegidos conforme a Lei Geral de Proteção de Dados (LGPD) e as melhores práticas de segurança
          </p>
        </div>
      </Modal>

      <Footer />
    </div>
  );
};

export default Confirmation;