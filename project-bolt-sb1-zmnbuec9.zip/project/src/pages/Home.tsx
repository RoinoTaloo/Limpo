import React from 'react';
import Header from '../components/Header';
import ProgramTitle from '../components/ProgramTitle';
import InfoSection from '../components/InfoSection';
import EligibilitySection from '../components/EligibilitySection';
import TrainingSection from '../components/TrainingSection';
import PartnersSection from '../components/PartnersSection';
import TimelineSection from '../components/TimelineSection';
import BenefitsSection from '../components/BenefitsSection';
import RegistrationSection from '../components/RegistrationSection';
import ResultsSection from '../components/ResultsSection';
import CTASection from '../components/CTASection';
import ContactSection from '../components/ContactSection';
import Footer from '../components/Footer';

const Home = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <div className="max-w-3xl mx-auto pb-10">
        <ProgramTitle />
        <InfoSection />
        <EligibilitySection />
        <TrainingSection />
        <PartnersSection />
        <TimelineSection />
        <BenefitsSection />
        <RegistrationSection />
        <ResultsSection />
        <CTASection />
        <ContactSection />
      </div>
      <Footer />
    </div>
  );
};

export default Home;