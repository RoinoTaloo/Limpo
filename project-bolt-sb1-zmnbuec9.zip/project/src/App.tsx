import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Registration from './pages/Registration';
import Confirmation from './pages/Confirmation';

function App() {
  // Update document title
  React.useEffect(() => {
    document.title = "Brasil Mais Limpo | Programa Nacional";
  }, []);

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-100">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/inscricao" element={<Registration />} />
          <Route path="/confirmacao" element={<Confirmation />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;